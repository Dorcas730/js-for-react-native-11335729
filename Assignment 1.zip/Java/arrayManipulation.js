function processArray(numbers) {
    return numbers.map(number => {
      if (number % 2 === 0) {
        return number ** 2;
      } else {
        return number * 3;
      }
    });
  }
  // Example usage:
const originalArray = [1, 2, 3, 4, 5, 6];
const processedArray = processArray(originalArray);
console.log(processedArray); // Output: [3, 4, 9, 16, 15, 36]


function processArray(numbers) {
  return numbers.map(number => {
    if (number % 2 === 0) {
      return number ** 2;
    } else {
      return number * 3;
    }
  });
}

function formatArrayStrings(strings, numbers) {
  return strings.map((string, index) => {
    const number = numbers[index];
    if (number % 2 === 0) {
      return string.toUpperCase();
    } else {
      return string.toLowerCase();
    }
  });
}
// Example usage:
const originalStrings = ["Hello", "World", "JavaScript", "Is", "Awesome"];
const processedNumbers = processArray([1, 2, 3, 4, 5]);
const formattedStrings = formatArrayStrings(originalStrings, processedNumbers);
console.log(formattedStrings); // Output: ["hello", "WORLD", "javascript", "IS", "awesome"]


