let userId = 1;

function createUserProfiles(names, modifiedNames) {
  const userProfiles = [];

  for (let i = 0; i < names.length; i++) {
    const user = {
      originalName: names[i],
      modifiedName: modifiedNames[i],
      id: userId
    };
    userProfiles.push(user);
    userId++;
  }

  return userProfiles;
}

// Example usage:
const names = ["John", "Alice", "Bob"];
const modifiedNames = ["JOHN", "alice", "BOB"];
const userProfiles = createUserProfiles(names, modifiedNames);

console.log(userProfiles);
// Output:
// [
//   { originalName: "John", modifiedName: "JOHN", id: 1 },
//   { originalName: "Alice", modifiedName: "alice", id: 2 },
//   { originalName: "Bob", modifiedName: "BOB", id: 3 }
// ]
