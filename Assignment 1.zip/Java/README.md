# README

Student ID: 11261988

This repository contains solutions to the following tasks:

Task 1: arrayManipulation.js
---------------------------

* Created a function `processArray` that takes an array of numbers and returns a new array with each even number squared and each odd number tripled.

Task 2 : added a function formatArrayStrings
---------------------------

* Created a function `formatArrayStrings` that takes two arrays (an array of strings and an array of numbers processed by `processArray`) and returns a new array with each string modified based on its corresponding number (capitalized if the number is even, lowercase if the number is odd).

Task 3: userInfo.js
------------------

* Created a function `createUserProfiles` that takes two arrays (an array of names and an array of modified names) and returns an array of objects, each containing `originalName`, `modifiedName`, and `id` (auto-incremented starting from 1).
